<?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="flex items-center mb-2 p-3 rounded-lg 
        <?php if($option->id == $selectedOptionId): ?>
            <?php if($option->id == $correctOptionId): ?>
                bg-green-50 border border-green-200
            <?php else: ?>
                bg-red-50 border border-red-200
            <?php endif; ?>
        <?php else: ?>
            <?php if($option->id == $correctOptionId): ?>
                bg-green-50 border border-green-200
            <?php else: ?>
                bg-gray-50
            <?php endif; ?>
        <?php endif; ?>">
        <div class="flex items-center h-5">
            <input type="radio" 
                   <?php if($option->id == $selectedOptionId): ?> checked <?php endif; ?>
                   disabled
                   class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500">
        </div>
        <div class="ml-3 text-sm">
            <label class="font-medium text-gray-700">
                <?php echo e($option->option); ?>

                <?php if($option->id == $correctOptionId && $option->id != $selectedOptionId): ?>
                    <span class="text-green-600 ml-2">(Respuesta correcta)</span>
                <?php endif; ?>
                <?php if($option->id == $selectedOptionId): ?>
                    <span class="ml-2">
                        <?php if($option->id == $correctOptionId): ?>
                            <span class="text-green-600">✓ Correcta</span>
                        <?php else: ?>
                            <span class="text-red-600">✗ Tu respuesta</span>
                        <?php endif; ?>
                    </span>
                <?php endif; ?>
            </label>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH /Users/joburbanop/Desktop/EvaluacionProfesores/resources/views/test-result.blade.php ENDPATH**/ ?>