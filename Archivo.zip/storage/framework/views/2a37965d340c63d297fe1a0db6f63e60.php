<div class="mb-4">
    <div class="flex items-center space-x-2 mb-2">
       
        <h3 class="text-lg font-semibold text-gray-800"><?php echo e($questionText); ?></h3>
    </div>
   
</div><?php /**PATH /Users/joburbanop/Desktop/EvaluacionProfesores/resources/views/question-header.blade.php ENDPATH**/ ?>