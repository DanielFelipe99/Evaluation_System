<?php

namespace App\Filament\Resources\RealizarTestResource\Pages;

use App\Filament\Resources\RealizarTestResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateRealizarTest extends CreateRecord
{
    protected static string $resource = RealizarTestResource::class;
}
