# Instrucciones para Despliegue en Hostinger

## Requisitos Previos
- Cuenta en Hostinger
- Acceso al panel de control de Hostinger
- Acceso FTP o SSH
- Base de datos MySQL creada en Hostinger

## Pasos para el Despliegue

### 1. Preparación del Proyecto
1. Asegúrate de que el proyecto esté en modo producción:
   ```bash
   npm run build
   php artisan config:cache
   php artisan route:cache
   php artisan view:cache
   ```

2. Verifica que el archivo `.env` tenga la configuración correcta:
   - `APP_ENV=production`
   - `APP_DEBUG=false`
   - `APP_URL=https://tu-dominio.com`
   - Configuración correcta de la base de datos
   - Configuración correcta del correo electrónico

### 2. Subida de Archivos
1. Conéctate por FTP a tu hosting
2. Sube todos los archivos del proyecto a la carpeta `public_html`
3. Asegúrate de que los permisos sean correctos:
   - Carpetas: 755
   - Archivos: 644
   - `storage` y `bootstrap/cache`: 775

### 3. Configuración de la Base de Datos
1. Crea una base de datos en el panel de Hostinger
2. Importa el archivo SQL de tu base de datos
3. Actualiza el archivo `.env` con los datos de conexión:
   ```
   DB_CONNECTION=mysql
   DB_HOST=localhost
   DB_PORT=3306
   DB_DATABASE=tu_base_de_datos
   DB_USERNAME=tu_usuario
   DB_PASSWORD=tu_contraseña
   ```

### 4. Configuración del Servidor
1. Asegúrate de que el documento raíz apunte a la carpeta `public`
2. Verifica que el archivo `.htaccess` esté correctamente configurado
3. Habilita el módulo `mod_rewrite` en Apache

### 5. Configuración de Correo
1. Configura los datos SMTP en el archivo `.env`:
   ```
   MAIL_MAILER=smtp
   MAIL_HOST=mail.tu-dominio.com
   MAIL_PORT=587
   MAIL_USERNAME=tu_correo@tu-dominio.com
   MAIL_PASSWORD=tu_contraseña
   MAIL_ENCRYPTION=tls
   MAIL_FROM_ADDRESS=tu_correo@tu-dominio.com
   MAIL_FROM_NAME="Evaluacion Profesores"
   ```

### 6. Comandos Finales
1. Ejecuta las migraciones:
   ```bash
   php artisan migrate
   ```

2. Limpia las cachés:
   ```bash
   php artisan config:clear
   php artisan cache:clear
   php artisan view:clear
   php artisan route:clear
   ```

3. Regenera las cachés:
   ```bash
   php artisan config:cache
   php artisan route:cache
   php artisan view:cache
   ```

### 7. Verificación
1. Accede a tu dominio para verificar que todo funcione correctamente
2. Prueba el inicio de sesión
3. Verifica el envío de correos
4. Comprueba que las rutas funcionen correctamente

## Solución de Problemas Comunes

### Error 500
1. Verifica los logs en `storage/logs/laravel.log`
2. Asegúrate de que los permisos sean correctos
3. Verifica la configuración de PHP en Hostinger

### Problemas con Tailwind CSS
1. Verifica que los archivos compilados estén en `public/build`
2. Asegúrate de que el archivo `manifest.json` esté presente
3. Verifica que las rutas en `vite.config.js` sean correctas

### Problemas con el Correo
1. Verifica la configuración SMTP en `.env`
2. Comprueba que el puerto 587 esté abierto
3. Verifica las credenciales del correo

## Soporte
Si encuentras algún problema, revisa:
1. Los logs de Laravel en `storage/logs/laravel.log`
2. Los logs de Apache en el panel de Hostinger
3. La documentación de Laravel y Hostinger 