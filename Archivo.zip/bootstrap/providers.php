<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\AuthServiceProvider::class,
    App\Providers\EventServiceProvider::class,
    App\Providers\Filament\AdminPanelProvider::class,
    App\Providers\Filament\CoordinadorPanelProvider::class,
    App\Providers\Filament\DocentePanelProvider::class,
    App\Providers\RouteServiceProvider::class,
];
