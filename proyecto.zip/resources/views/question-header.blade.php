<div class="mb-4">
    <div class="flex items-center space-x-2 mb-2">
       
        <h3 class="text-lg font-semibold text-gray-800">{{ $questionText }}</h3>
    </div>
   
</div>