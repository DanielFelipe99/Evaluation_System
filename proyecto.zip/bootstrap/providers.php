<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\Filament\AdminPanelProvider::class,
    App\Providers\Filament\CoordinadorPanelPanelProvider::class,
    App\Providers\Filament\DocentePanelPanelProvider::class,
];
